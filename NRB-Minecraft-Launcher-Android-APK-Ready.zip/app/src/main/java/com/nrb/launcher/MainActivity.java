package com.nrb.launcher;

import android.app.Activity;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.widget.*;
import android.view.View;

public class MainActivity extends Activity {

    private SharedPreferences prefs;
    private TextView console;
    private Spinner versionSpinner;
    private Spinner ramSpinner;
    private EditText javaPath;
    private EditText gameDirectory;

    private final String[] versions = {
        "Minecraft 1.21.8",
        "Minecraft 1.21.5",
        "Minecraft 1.21.4",
        "Minecraft 1.20.6",
        "Minecraft 1.20.1",
        "Minecraft 1.16.5",
        "Minecraft 1.12.2",
        "Minecraft 1.8.9"
    };

    private final String[] ramOptions = {
        "2 GB", "4 GB", "6 GB", "8 GB", "12 GB", "16 GB"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(com.nrb.launcher.R.layout.activity_main);

        prefs = getSharedPreferences("nrb_launcher", MODE_PRIVATE);

        console = findViewById(R.id.console);
        versionSpinner = findViewById(R.id.versionSpinner);
        ramSpinner = findViewById(R.id.ramSpinner);
        javaPath = findViewById(R.id.javaPath);
        gameDirectory = findViewById(R.id.gameDirectory);

        setupSpinners();
        loadSettings();

        findViewById(R.id.playButton).setOnClickListener(v -> play());
        findViewById(R.id.saveButton).setOnClickListener(v -> saveSettings());

        log("NRB Minecraft Launcher started.");
        log("Android Edition v1.0.0");
        log("Stage 1 launcher initialized.");
    }

    private void setupSpinners() {
        ArrayAdapter<String> versionsAdapter =
                new ArrayAdapter<>(this,
                        android.R.layout.simple_spinner_dropdown_item,
                        versions);

        versionSpinner.setAdapter(versionsAdapter);

        ArrayAdapter<String> ramAdapter =
                new ArrayAdapter<>(this,
                        android.R.layout.simple_spinner_dropdown_item,
                        ramOptions);

        ramSpinner.setAdapter(ramAdapter);

        versionSpinner.setOnItemSelectedListener(
                new android.widget.AdapterView.OnItemSelectedListener() {
                    public void onNothingSelected(android.widget.AdapterView<?> parent) {}

                    public void onItemSelected(
                            android.widget.AdapterView<?> parent,
                            View view,
                            int position,
                            long id) {
                        prefs.edit()
                                .putInt("version", position)
                                .apply();
                    }
                });

        ramSpinner.setOnItemSelectedListener(
                new android.widget.AdapterView.OnItemSelectedListener() {
                    public void onNothingSelected(android.widget.AdapterView<?> parent) {}

                    public void onItemSelected(
                            android.widget.AdapterView<?> parent,
                            View view,
                            int position,
                            long id) {
                        prefs.edit()
                                .putInt("ram", position)
                                .apply();
                    }
                });
    }

    private void loadSettings() {
        versionSpinner.setSelection(
                prefs.getInt("version", 0)
        );

        ramSpinner.setSelection(
                prefs.getInt("ram", 1)
        );

        javaPath.setText(
                prefs.getString("javaPath", "")
        );

        gameDirectory.setText(
                prefs.getString("gameDirectory", "")
        );
    }

    private void saveSettings() {
        prefs.edit()
                .putString("javaPath",
                        javaPath.getText().toString())
                .putString("gameDirectory",
                        gameDirectory.getText().toString())
                .apply();

        log("Settings saved.");
        Toast.makeText(
                this,
                "NRB settings saved",
                Toast.LENGTH_SHORT
        ).show();
    }

    private void play() {
        String version =
                versionSpinner.getSelectedItem().toString();

        String ram =
                ramSpinner.getSelectedItem().toString();

        log("Preparing Minecraft launch...");
        log("Version: " + version);
        log("RAM: " + ram);
        log("Stage 1 does not contain the Minecraft launch engine.");
        log("Stage 2 will add account authentication, version files, assets and launching.");

        Toast.makeText(
                this,
                "Stage 2 Minecraft engine not installed yet",
                Toast.LENGTH_LONG
        ).show();
    }

    private void log(String message) {
        String old = console.getText().toString();
        console.setText(old + message + "\n");
    }
}
