# NRB Minecraft Launcher — Android Edition

Stage 1 APK-ready Android project.

## Features
- NRB branding
- Dashboard
- Minecraft version selector
- RAM selector
- Server cards
- Java path setting
- Game directory setting
- Persistent settings using SharedPreferences
- Play button and console/log area

## Build

Open this folder in Android Studio and run:

./gradlew assembleDebug

The APK will be created at:

app/build/outputs/apk/debug/app-debug.apk

## Stage 2

The real Minecraft engine is intentionally not included in Stage 1.
Stage 2 can add account authentication, version manifests, game assets,
libraries, Java/runtime handling, and legitimate Minecraft launching.
