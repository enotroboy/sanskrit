const questions = [

    // =====================================================
    // CHAPTER 1 — अहं नमामि
    // =====================================================

    {
        chapter: 1,
        question: "गुरुं ______ सादरम्।",
        options: [
            { text: "नमामि", correct: true },
            { text: "पठामि", correct: false }
        ]
    },

    {
        chapter: 1,
        question: "हितं करोमि ______।",
        options: [
            { text: "सर्वदा", correct: true },
            { text: "कदापि", correct: false }
        ]
    },

    {
        chapter: 1,
        question: "______ नीति-सत्पथे।",
        options: [
            { text: "चलामि", correct: true },
            { text: "धारयामि", correct: false }
        ]
    },

    {
        chapter: 1,
        question: "दधामि ______ व्रतम्।",
        options: [
            { text: "साधुतावताम्", correct: true },
            { text: "प्रियवचनम्", correct: false }
        ]
    },

    {
        chapter: 1,
        question: "______ कीर्तिसत्कथाम्।",
        options: [
            { text: "सृजामि", correct: true },
            { text: "हरामि", correct: false }
        ]
    },


    // ---- Chapter 1: एकशब्देन उत्तर ----

    {
        chapter: 1,
        question: "किं करोमि सर्वदा?",
        options: [
            { text: "हितं करोमि", correct: true },
            { text: "दुःखं करोमि", correct: false }
        ]
    },

    {
        chapter: 1,
        question: "अहं प्रभुं कथं जपामि?",
        options: [
            { text: "सादरम्", correct: true },
            { text: "शीघ्रम्", correct: false }
        ]
    },

    {
        chapter: 1,
        question: "अहं कां हरामि?",
        options: [
            { text: "मातृभूमेः व्यथाम्", correct: true },
            { text: "वार्तापत्रम्", correct: false }
        ]
    },

    {
        chapter: 1,
        question: "अहं किं दधामि?",
        options: [
            { text: "साधुतावताम् व्रतम्", correct: true },
            { text: "उपनेत्रम्", correct: false }
        ]
    },

    {
        chapter: 1,
        question: "अहं कां सृजामि?",
        options: [
            { text: "कीर्तिसत्कथाम्", correct: true },
            { text: "मातृव्यथाम्", correct: false }
        ]
    },


    // ---- Chapter 1: पूर्णवाक्य ----

    {
        chapter: 1,
        question: "त्वं नित्यं कां नमसि?",
        options: [
            { text: "अहं मातरं नमामि।", correct: true },
            { text: "अहं मातरं हरामि।", correct: false }
        ]
    },

    {
        chapter: 1,
        question: "त्वं स्वयं किं किं करोषि?",
        options: [
            { text: "अहं स्वयं पठामि, सृजामि च।", correct: true },
            { text: "अहं स्वयं न पठामि।", correct: false }
        ]
    },

    {
        chapter: 1,
        question: "त्वं कस्यां व्यथां हरसि?",
        options: [
            { text: "अहं मातृभूमेः व्यथां हरामि।", correct: true },
            { text: "अहं वार्तापत्रस्य व्यथां हरामि।", correct: false }
        ]
    },

    {
        chapter: 1,
        question: "त्वं किं धारयसि?",
        options: [
            { text: "अहं साधुतावतां व्रतं धारयामि।", correct: true },
            { text: "अहं उपनेत्रं धारयामि।", correct: false }
        ]
    },

    {
        chapter: 1,
        question: "त्वं कां सृजसि?",
        options: [
            { text: "अहं कीर्तिसत्कथां सृजामि।", correct: true },
            { text: "अहं वार्तापत्रं सृजामि।", correct: false }
        ]
    },


    // =====================================================
    // CHAPTER 2 — मातामह्याः उपनेत्रम्
    // =====================================================

    {
        chapter: 2,
        question: "मातामही प्रतिदिनं किं पठति?",
        options: [
            { text: "वार्तापत्रम्", correct: true },
            { text: "क्रीडापुस्तकम्", correct: false }
        ]
    },

    {
        chapter: 2,
        question: "कस्य अधः मुनुमुनुः उपविष्टः आसीत्?",
        options: [
            { text: "पर्यङ्कस्य", correct: true },
            { text: "दर्पणस्य", correct: false }
        ]
    },

    {
        chapter: 2,
        question: "प्रायशः कः समयः आसीत्?",
        options: [
            { text: "सार्ध-पञ्चवादन-समयः", correct: true },
            { text: "द्विवादन-समयः", correct: false }
        ]
    },

    {
        chapter: 2,
        question: "उपनेत्रं कस्य पादयोः मध्ये आसीत्?",
        options: [
            { text: "मुनुमुनस्य", correct: true },
            { text: "रमायाः", correct: false }
        ]
    },

    {
        chapter: 2,
        question: "मातामही प्रतिदिनं कदा वार्तापत्रं पठति?",
        options: [
            { text: "प्रातः", correct: true },
            { text: "सायंकाले", correct: false }
        ]
    },

    {
        chapter: 2,
        question: "उपनेत्रं धृत्वा कः शोभनः दृश्यते स्म?",
        options: [
            { text: "मुनुमुनुः", correct: true },
            { text: "रामायाः भ्राता", correct: false }
        ]
    },


    // ---- Chapter 2: आम् / न ----

    {
        chapter: 2,
        question: "उपनेत्रं विना मातामही कष्टम् अनुभवति स्म।",
        options: [
            { text: "आम्", correct: true },
            { text: "न", correct: false }
        ]
    },

    {
        chapter: 2,
        question: "रमा कपाटिकायाम् उपनेत्रम् अन्विष्यति।",
        options: [
            { text: "आम्", correct: true },
            { text: "न", correct: false }
        ]
    },

    {
        chapter: 2,
        question: "पर्यङ्कस्य अधः मुनुमुनुः उपविष्टः आसीत्।",
        options: [
            { text: "आम्", correct: true },
            { text: "न", correct: false }
        ]
    },

    {
        chapter: 2,
        question: "मुनुमुनस्य पादयोः मध्ये उपनेत्रम् आसीत्।",
        options: [
            { text: "आम्", correct: true },
            { text: "न", correct: false }
        ]
    },

    {
        chapter: 2,
        question: "रमा उपनेत्रं स्नानागारे अन्विष्यति।",
        options: [
            { text: "आम्", correct: true },
            { text: "न", correct: false }
        ]
    },

    {
        chapter: 2,
        question: "मातामही प्रतिदिनं प्रातः वार्तापत्रं न पठति।",
        options: [
            { text: "न", correct: true },
            { text: "आम्", correct: false }
        ]
    },


    // ---- Chapter 2: विलोमशब्द ----

    {
        chapter: 2,
        question: "अधः इत्यस्य विलोमशब्दः कः?",
        options: [
            { text: "उपरि", correct: true },
            { text: "बहिः", correct: false }
        ]
    },

    {
        chapter: 2,
        question: "अन्तः इत्यस्य विलोमशब्दः कः?",
        options: [
            { text: "बहिः", correct: true },
            { text: "दूरम्", correct: false }
        ]
    },

    {
        chapter: 2,
        question: "समीपम् इत्यस्य विलोमशब्दः कः?",
        options: [
            { text: "दूरम्", correct: true },
            { text: "उपरि", correct: false }
        ]
    },

    {
        chapter: 2,
        question: "मन्दम् इत्यस्य विलोमशब्दः कः?",
        options: [
            { text: "सत्वरम्", correct: true },
            { text: "दुःखिता", correct: false }
        ]
    },

    {
        chapter: 2,
        question: "प्रसन्ना इत्यस्य विलोमशब्दः कः?",
        options: [
            { text: "दुःखिता", correct: true },
            { text: "सत्वरम्", correct: false }
        ]
    }

];