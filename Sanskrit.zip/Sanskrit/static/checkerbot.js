/*
 * CheckerBot - Iravati Sanskrit Question Checker
 *
 * Separate, reusable browser module.
 * It works with /static/chapters.json (or any compatible question database).
 * It does NOT invent textbook answers: it checks against answers stored in the database.
 */

(function (global) {
  'use strict';

  const CheckerBot = {
    data: [],

    async load(url = '/static/chapters.json') {
      const response = await fetch(url, { cache: 'no-store' });
      if (!response.ok) throw new Error(`Question database could not be loaded (${response.status})`);
      this.data = await response.json();
      return this.data;
    },

    normalize(value) {
      return String(value ?? '')
        .normalize('NFC')
        .replace(/[।॥,;:!?"'“”‘’(){}\[\]<>]/g, ' ')
        .replace(/\s+/g, ' ')
        .trim()
        .toLocaleLowerCase('sa-IN');
    },

    answerList(answer) {
      if (Array.isArray(answer)) return answer.filter(Boolean).map(String);
      if (answer == null) return [];
      return [String(answer)];
    },

    isCorrect(userAnswer, correctAnswer) {
      const given = this.normalize(userAnswer);
      if (!given) return false;
      return this.answerList(correctAnswer).some(answer => {
        const expected = this.normalize(answer);
        return expected && (given === expected || given.split(' / ').includes(expected));
      });
    },

    flattenChapter(chapterNumber) {
      const chapter = this.data.find(c => Number(c.chapter) === Number(chapterNumber));
      if (!chapter) return [];
      const result = [];
      (chapter.exercises || []).forEach(exercise => {
        (exercise.items || []).forEach((item, index) => {
          if (Array.isArray(item) && item.length >= 3) {
            result.push({
              id: `${chapter.chapter}-${exercise.no}-${item[0] || index + 1}`,
              chapter: Number(chapter.chapter),
              exerciseNo: exercise.no,
              type: exercise.type || 'question',
              label: item[0] || String(index + 1),
              question: item[1],
              answer: item[2],
              options: Array.isArray(item[3]) ? item[3] : []
            });
          } else if (item && typeof item === 'object') {
            result.push({
              id: item.id || `${chapter.chapter}-${exercise.no}-${index + 1}`,
              chapter: Number(chapter.chapter),
              exerciseNo: exercise.no,
              type: item.type || exercise.type || 'question',
              label: item.label || String(index + 1),
              question: item.question || item.q || '',
              answer: item.answer ?? item.a ?? '',
              options: Array.isArray(item.options) ? item.options : []
            });
          }
        });
      });
      return result.filter(q => q.question);
    },

    getSimilarQuestions(chapterNumber, currentId = null, count = 3) {
      const all = this.flattenChapter(chapterNumber).filter(q => q.id !== currentId);
      return all.sort(() => Math.random() - 0.5).slice(0, Math.max(0, count));
    },

    check(question, userAnswer) {
      const correct = this.isCorrect(userAnswer, question.answer);
      return {
        correct,
        questionId: question.id,
        userAnswer,
        correctAnswer: question.answer,
        message: correct ? 'सही उत्तर! ✓' : 'उत्तर सही नहीं है।',
        similarQuestions: this.getSimilarQuestions(question.chapter, question.id, 3)
      };
    },

    createTest(chapterNumber, count = 10) {
      const all = this.flattenChapter(chapterNumber);
      return all.sort(() => Math.random() - 0.5).slice(0, Math.max(1, count));
    },

    getAnswer(question) {
      return this.answerList(question.answer);
    }
  };

  global.CheckerBot = CheckerBot;
})(window);
