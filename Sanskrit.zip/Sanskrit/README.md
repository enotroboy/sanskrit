# Sanskrit Test Site

## Run
```bash
pip install -r requirements.txt
python app.py
```

Railway start command: `python app.py`
The app uses Railway's `PORT` automatically (8080 fallback).

Test account: `admin` / `admin`

`site.db` is created automatically on first start.
