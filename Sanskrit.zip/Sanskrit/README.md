# Sanskrit Test Site

## Run
```bash
pip install -r requirements.txt
python app.py
```

Railway start command: `python app.py`
The app uses Railway's `PORT` automatically (8080 fallback).

Test account: `admin` / `admin`

`site.db` is created automatically on first start.


## Admin / Cheating Monitor

The default administrator is `admin` / `admin`. Change this password before real use.

The admin dashboard is available at `/admin`. During a quiz, the site records activity indicators such as tab switching, window focus loss, copy/paste/cut, context-menu attempts, fullscreen exits, and developer-tools shortcuts. The monitor does not capture private screen contents or keystrokes.
