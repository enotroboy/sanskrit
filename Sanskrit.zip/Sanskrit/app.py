from flask import Flask, render_template, request, redirect, url_for, session, flash
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3
from pathlib import Path

app = Flask(__name__)

import os
app.secret_key = os.environ.get("SECRET_KEY", "change-this-secret")

BASE_DIR = Path(__file__).resolve().parent
DB = BASE_DIR / "site.db"


def get_db():
    return sqlite3.connect(DB)


def init_db():

    with get_db() as con:

        con.execute("""
            CREATE TABLE IF NOT EXISTS users (
                username TEXT PRIMARY KEY,
                password_hash TEXT NOT NULL,
                role TEXT NOT NULL DEFAULT 'student'
            )
        """)

        # Upgrade older databases that were created before roles existed.
        columns = [row[1] for row in con.execute("PRAGMA table_info(users)").fetchall()]
        if "role" not in columns:
            con.execute("ALTER TABLE users ADD COLUMN role TEXT NOT NULL DEFAULT 'student'")

        con.execute("""
            CREATE TABLE IF NOT EXISTS cheat_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL,
                event_type TEXT NOT NULL,
                details TEXT,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            )
        """)

        # Create the default administrator account.
        existing = con.execute(
            "SELECT username FROM users WHERE username = ?",
            ("admin",)
        ).fetchone()

        if existing is None:
            con.execute(
                """
                INSERT INTO users (username, password_hash, role)
                VALUES (?, ?, ?)
                """,
                ("admin", generate_password_hash("admin"), "admin")
            )
        else:
            con.execute(
                "UPDATE users SET role = 'admin' WHERE username = 'admin'"
            )

        con.commit()


def current_user_role():
    username = session.get("username")
    if not username:
        return None
    with get_db() as con:
        row = con.execute(
            "SELECT role FROM users WHERE username = ?",
            (username,)
        ).fetchone()
    return row[0] if row else None


def log_event(username, event_type, details=""):
    if not username:
        return
    # Keep event details short and harmless; this is an audit log, not content capture.
    details = str(details)[:500]
    with get_db() as con:
        con.execute(
            """
            INSERT INTO cheat_events (username, event_type, details)
            VALUES (?, ?, ?)
            """,
            (username, event_type, details)
        )
        con.commit()


@app.route("/")
def home():

    if session.get("username"):
        return redirect(url_for("dashboard"))

    return redirect(url_for("login"))


@app.route("/login", methods=["GET", "POST"])
def login():

    if request.method == "POST":

        username = request.form.get(
            "username", ""
        ).strip()

        password = request.form.get(
            "password", ""
        )

        if not username or not password:

            flash(
                "Username and password are required."
            )

            return render_template("login.html")


        with get_db() as con:

            user = con.execute(
                """
                SELECT username, password_hash, role
                FROM users
                WHERE username = ?
                """,
                (username,)
            ).fetchone()


        if user and check_password_hash(
            user[1],
            password
        ):

            session.clear()

            session["username"] = user[0]
            session["role"] = user[2] or "student"
            log_event(user[0], "login", "Successful login")

            return redirect(
                url_for("dashboard")
            )


        flash(
            "Invalid username or password."
        )


    return render_template("login.html")


@app.route("/register", methods=["GET", "POST"])
def register():

    if request.method == "POST":

        username = request.form.get(
            "username", ""
        ).strip()

        password = request.form.get(
            "password", ""
        )


        if not username or not password:

            flash(
                "Username and password are required."
            )

            return render_template(
                "register.html"
            )


        if len(password) < 8:

            flash(
                "Password must be at least 8 characters."
            )

            return render_template(
                "register.html"
            )


        try:

            with get_db() as con:

                con.execute(
                    """
                    INSERT INTO users
                    (username, password_hash, role)
                    VALUES (?, ?, 'student')
                    """,
                    (
                        username,
                        generate_password_hash(
                            password
                        )
                    )
                )

                con.commit()


            flash(
                "Account created successfully. Please log in."
            )

            return redirect(
                url_for("login")
            )


        except sqlite3.IntegrityError:

            flash(
                "Username already exists."
            )


    return render_template(
        "register.html"
    )


@app.route("/dashboard")
def dashboard():

    if not session.get("username"):

        return redirect(
            url_for("login")
        )


    return render_template(
        "dashboard.html",
        username=session["username"]
    )


@app.route("/api/cheat-event", methods=["POST"])
def cheat_event():
    if not session.get("username"):
        return {"ok": False, "error": "login required"}, 401

    data = request.get_json(silent=True) or {}
    event_type = str(data.get("event_type", "suspicious_activity"))[:100]
    details = str(data.get("details", ""))[:500]

    allowed = {
        "tab_switch",
        "window_blur",
        "copy",
        "paste",
        "cut",
        "context_menu",
        "fullscreen_exit",
        "devtools_shortcut",
        "quiz_started",
        "quiz_finished"
    }
    if event_type not in allowed:
        event_type = "suspicious_activity"

    log_event(session["username"], event_type, details)
    return {"ok": True}


@app.route("/admin")
def admin():
    if not session.get("username"):
        return redirect(url_for("login"))

    if current_user_role() != "admin":
        flash("Admin access only.")
        return redirect(url_for("dashboard"))

    with get_db() as con:
        events = con.execute("""
            SELECT id, username, event_type, details, created_at
            FROM cheat_events
            ORDER BY id DESC
            LIMIT 500
        """).fetchall()

        stats = con.execute("""
            SELECT
                COUNT(*) AS total,
                COUNT(DISTINCT username) AS users,
                SUM(CASE WHEN event_type IN
                    ('tab_switch','window_blur','copy','paste','cut',
                     'context_menu','fullscreen_exit','devtools_shortcut')
                    THEN 1 ELSE 0 END) AS suspicious
            FROM cheat_events
        """).fetchone()

    return render_template(
        "admin.html",
        username=session["username"],
        events=events,
        stats=stats
    )


@app.route("/logout")
def logout():

    if session.get("username"):
        log_event(session["username"], "logout", "User logged out")

    session.clear()

    return redirect(
        url_for("login")
    )


if __name__ == "__main__":

    init_db()

    port = int(os.environ.get("PORT", "8080"))

    app.run(
        host="0.0.0.0",
        port=port,
        debug=False
    )