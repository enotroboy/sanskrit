from flask import Flask, render_template, request, redirect, url_for, session, flash
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3
from pathlib import Path

app = Flask(__name__)

import os
app.secret_key = os.environ.get("SECRET_KEY", "change-this-secret")

BASE_DIR = Path(__file__).resolve().parent
DB = BASE_DIR / "site.db"


def get_db():
    return sqlite3.connect(DB)


def init_db():

    with get_db() as con:

        con.execute("""
            CREATE TABLE IF NOT EXISTS users (
                username TEXT PRIMARY KEY,
                password_hash TEXT NOT NULL
            )
        """)

        # Create default admin account
        existing = con.execute(
            "SELECT username FROM users WHERE username = ?",
            ("admin",)
        ).fetchone()

        if existing is None:

            con.execute(
                """
                INSERT INTO users
                (username, password_hash)
                VALUES (?, ?)
                """,
                (
                    "admin",
                    generate_password_hash("admin")
                )
            )

        con.commit()


@app.route("/")
def home():

    if session.get("username"):
        return redirect(url_for("dashboard"))

    return redirect(url_for("login"))


@app.route("/login", methods=["GET", "POST"])
def login():

    if request.method == "POST":

        username = request.form.get(
            "username", ""
        ).strip()

        password = request.form.get(
            "password", ""
        )

        if not username or not password:

            flash(
                "Username and password are required."
            )

            return render_template("login.html")


        with get_db() as con:

            user = con.execute(
                """
                SELECT username, password_hash
                FROM users
                WHERE username = ?
                """,
                (username,)
            ).fetchone()


        if user and check_password_hash(
            user[1],
            password
        ):

            session.clear()

            session["username"] = user[0]

            return redirect(
                url_for("dashboard")
            )


        flash(
            "Invalid username or password."
        )


    return render_template("login.html")


@app.route("/register", methods=["GET", "POST"])
def register():

    if request.method == "POST":

        username = request.form.get(
            "username", ""
        ).strip()

        password = request.form.get(
            "password", ""
        )


        if not username or not password:

            flash(
                "Username and password are required."
            )

            return render_template(
                "register.html"
            )


        if len(password) < 8:

            flash(
                "Password must be at least 8 characters."
            )

            return render_template(
                "register.html"
            )


        try:

            with get_db() as con:

                con.execute(
                    """
                    INSERT INTO users
                    (username, password_hash)
                    VALUES (?, ?)
                    """,
                    (
                        username,
                        generate_password_hash(
                            password
                        )
                    )
                )

                con.commit()


            flash(
                "Account created successfully. Please log in."
            )

            return redirect(
                url_for("login")
            )


        except sqlite3.IntegrityError:

            flash(
                "Username already exists."
            )


    return render_template(
        "register.html"
    )


@app.route("/dashboard")
def dashboard():

    if not session.get("username"):

        return redirect(
            url_for("login")
        )


    return render_template(
        "dashboard.html",
        username=session["username"]
    )


@app.route("/logout")
def logout():

    session.clear()

    return redirect(
        url_for("login")
    )


if __name__ == "__main__":

    init_db()

    port = int(os.environ.get("PORT", "8080"))

    app.run(
        host="0.0.0.0",
        port=port,
        debug=False
    )